# PointProgrammerNet

This package contains the models and training code used for the experiments in
the accompanying paper. PointProgrammerNet summarizes an unordered point set
with three additive fast-weight states of fixed size. The states may be built
from a complete cloud or from separate chunks and then added together.

## Models

`PointProgrammerSegmenter` uses three `128 x 170` second-order states with
initial radii `0.08`, `0.20`, and `0.60`. Each query coordinate reads all three
states. Their 160-channel outputs are concatenated with a 32-channel encoding
of the query coordinate and the object category before pointwise prediction.
The model has 366,389 trainable parameters.

`PointProgrammerClassifier` uses the same three state shapes. Each state is
summarized directly from its rows. The middle summary is the reference, and a
bounded residual from the fine and broad summaries refines it before
classification. The model has 529,426 trainable parameters. Only the middle
radius uses a 25-fold learning-rate multiplier.

Neither model pools over reconstructed point features. Classification retains
no input points after the states have been written. Segmentation needs only the
fixed states, the requested coordinates, and the ShapeNetPart object category.

## Environment

Python 3.10 or newer is recommended. The reported environment used Python
3.10.20, PyTorch 2.5.1, CUDA 12.1, NumPy 2.0.1, and h5py 3.16.0.

```powershell
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python .\verify_streaming.py
```

The verification program compares one-shot, shuffled, and chunked writes and
checks fixed retained memory. Each sample retains three float32 `128 x 170`
matrices: 261,120 bytes (255 KiB), independent of the number of observed
points.

## Data

Segmentation uses ShapeNetPart. Classification uses the ModelNet40
`modelnet40_ply_hdf5_2048` release. Both loaders center each object and divide
XYZ by its largest absolute coordinate. The reported models use XYZ only.

## Reproduce the reported training runs

```powershell
python .\train_segmentation.py --data-dir C:\path\to\ShapeNetPart --seeds 0,1,2 --epochs 20
python .\train_classification.py --data-dir C:\path\to\modelnet40_ply_hdf5_2048 --seeds 0,1,2 --epochs 20
```

The defaults match the paper: 1,024 points, AdamW, base learning rate `3e-3`,
weight decay `1e-4`, cosine learning-rate decay, segmentation batch size 16,
classification batch size 32, and classification label smoothing 0.1.

For a short installation check:

```powershell
python .\train_segmentation.py --data-dir C:\path\to\ShapeNetPart --seeds 0 --epochs 1 --train-limit 32 --test-limit 16
python .\train_classification.py --data-dir C:\path\to\modelnet40_ply_hdf5_2048 --seeds 0 --epochs 1 --train-limit 64 --test-limit 32
```

## Streaming interface

Both models provide `build_states(points)` and `merge_states(...)`:

```python
state_a = model.build_states(points_a)
state_b = model.build_states(points_b)
history = model.merge_states(state_a, state_b)
```

For segmentation, use
`predict_from_states(query_coordinates, categories, history)`. For
classification, use `classify_states(history)`. Addition merges new evidence,
subtraction removes a separately stored subset state, and multiplying a state
by a scalar implements exponential decay.

`reference_results.json` records the three-seed results and exact protocols
reported in the paper.
